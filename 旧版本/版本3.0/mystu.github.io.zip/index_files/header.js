var m=1;
var n=Math.floor(Math.random()*m+1);
switch(n)
{
case 1:
document.writeln("<a href=\"http:\/\/temai.taobao.com\/cheap.htm?pt=1&pid=mm_30090119_3425689_13394705\"><\/a>");
break;
}
